package core;


public class CPT_AttackStep extends AttackStep {

   public CPT_AttackStep() {
      // TODO Auto-generated constructor stub
   }

}
